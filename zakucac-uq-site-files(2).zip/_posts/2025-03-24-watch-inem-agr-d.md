---
title: Agregat D - Watch datoteke
author: admilara
date: 2025-03-24
category: Jekyll
layout: post
---
<style scoped>
table {
  font-size: 12px;
}
</style>


<span style="font-size: 20px; font-weight: bold; color: red; font-family: Helvetica; text-align: center">
    UQ regulacija na sučelju (D) - 05.03.2025.
</span>
<span style="font-size: 18px; font-weight: bold; color: red; font-family: Helvetica; text-align: center">
    Podatci: Končar INEM
</span>

Za vrijeme trajanja cijelog pokusa agregata D u režimu regulacije jalove snage i napona na sučelju,
snimani su Watch zapisi iz sustava uzbude. Pokus na agregatu D napravljen je 05.03.2025. 

{% capture raw_html %}
<table>
    <thead>
        <tr>
            <th style="text-align:center; font-family: Helvetica">Zapis</th>
            <th style="text-align:center; font-family: Helvetica">Početak</th>
            <th style="text-align:center; font-family: Helvetica">Kraj</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-002/">Watch 002</a></td>
            <td style="text-align:center">12:55:18.097</td>
            <td style="text-align:center">13:02:45.704</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-003/">Watch 003</a></td>
            <td style="text-align:center">13:02:46.098</td>
            <td style="text-align:center">13:05:47.458</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-004/">Watch 004</a></td>
            <td style="text-align:center">13:05:48.098</td>
            <td style="text-align:center">13:12:46.375</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-005/">Watch 005</a></td>
            <td style="text-align:center">13:12:47.073</td>
            <td style="text-align:center">13:16:24.630</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-006/">Watch 006</a></td>
            <td style="text-align:center">13:16:24.098</td>
            <td style="text-align:center">13:22:47.145</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-007/">Watch 007</a></td>
            <td style="text-align:center">13:22:48.720</td>
            <td style="text-align:center">13:28:47.459</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-008/">Watch 008</a></td>
            <td style="text-align:center">13:28:48.722</td>
            <td style="text-align:center">13:35:04.213</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-009/">Watch 009</a></td>
            <td style="text-align:center">13:35:05.723</td>
            <td style="text-align:center">13:41:04.386</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-010/">Watch 010</a></td>
            <td style="text-align:center">13:41:05.724</td>
            <td style="text-align:center">13:47:29.819</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-011/">Watch 011</a></td>
            <td style="text-align:center">13:47:31.738</td>
            <td style="text-align:center">13:55:00.623</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-012/">Watch 012</a></td>
            <td style="text-align:center">13:55:01.724</td>
            <td style="text-align:center">14:00:57.423</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-013/">Watch 013</a></td>
            <td style="text-align:center">14:00:58.705</td>
            <td style="text-align:center">14:10:41.298</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-014/">Watch 014</a></td>
            <td style="text-align:center">14:10:42.721</td>
            <td style="text-align:center">14:16:31.231</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-015/">Watch 015</a></td>
            <td style="text-align:center">14:16:32.724</td>
            <td style="text-align:center">14:22:23.078</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-016/">Watch 016</a></td>
            <td style="text-align:center">14:22:24.723</td>
            <td style="text-align:center">14:26:19.449</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-017/">Watch 017</a></td>
            <td style="text-align:center">14:26:20.749</td>
            <td style="text-align:center">14:30:15.500</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-018/">Watch 018</a></td>
            <td style="text-align:center">14:30:17.725</td>
            <td style="text-align:center">14:34:10.172</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-042/">Watch 042</a></td>
            <td style="text-align:center">14:34:10.175</td>
            <td style="text-align:center">14:34:21.324</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-066/">Watch 066</a></td>
            <td style="text-align:center">14:34:21.041</td>
            <td style="text-align:center">14:39:47.702</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-067/">Watch 067</a></td>
            <td style="text-align:center">14:39:49.705</td>
            <td style="text-align:center">14:46:58.272</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-068/">Watch 068</a></td>
            <td style="text-align:center">14:46:59.724</td>
            <td style="text-align:center">14:52:46.182</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-069/">Watch 069</a></td>
            <td style="text-align:center">14:52:47.710</td>
            <td style="text-align:center">14:58:43.550</td>
        </tr> 
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-070/">Watch 070</a></td>
            <td style="text-align:center">14:58:44.741</td>
            <td style="text-align:center">15:04:30.250</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-071/">Watch 071</a></td>
            <td style="text-align:center">15:04:31.724</td>
            <td style="text-align:center">15:08:53.966</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-072/">Watch 072</a></td>
            <td style="text-align:center">15:08:55.723</td>
            <td style="text-align:center">15:14:42.611</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-073/">Watch 073</a></td>
            <td style="text-align:center">15:14:43.723</td>
            <td style="text-align:center">15:20:37.039</td>
        </tr> 
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-074/">Watch 074</a></td>
            <td style="text-align:center">15:20:38.698</td>
            <td style="text-align:center">15:26:22.148</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-075/">Watch 075</a></td>
            <td style="text-align:center">15:26:23.727</td>
            <td style="text-align:center">15:30:52.860</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-076/">Watch 076</a></td>
            <td style="text-align:center">15:31:10.705</td>
            <td style="text-align:center">15:36:14.843</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-077/">Watch 077</a></td>
            <td style="text-align:center">15:36:16.739</td>
            <td style="text-align:center">15:40:29.238</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-078/">Watch 078</a></td>
            <td style="text-align:center">15:40:30.735</td>
            <td style="text-align:center">15:46:15.998</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-079/">Watch 079</a></td>
            <td style="text-align:center">15:46:17.698</td>
            <td style="text-align:center">15:51:23.837</td>
        </tr>
        <tr>
            <td style="text-align:center"><a href="{{ site.baseurl }}/watch-md-d/watch-zakuca1d-zakuca1d-080/">Watch 080</a></td>
            <td style="text-align:center">15:51:24.717</td>
            <td style="text-align:center">15:56:06.241</td>
        </tr>                                 
    </tbody>
</table>
{% endcapture %}
{{ raw_html }}